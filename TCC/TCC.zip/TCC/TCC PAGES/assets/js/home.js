function alerta() {
    alert("Recurso indisponível no momento...")

}